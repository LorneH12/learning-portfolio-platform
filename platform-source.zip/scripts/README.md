# Local pilot operator notes
This is original modular player and authoring code, not Adapt or eXeLearning. No cross-tool authoring interchange has been verified.
Run npm.cmd install, npm.cmd run build, npm.cmd test, and npm.cmd start from the platform directory with Node 24.
Place complete parent-authored course JSON in content/*.json. Build validates every source and generates the catalog, standalone static output, and candidate SCORM 1.2 ZIPs.
The server binds only to 127.0.0.1:4173. It stores synthetic development events in .runtime/pilot.sqlite. This queue is NOT an LRS or multi-user authenticated LMS.
LRS_ENDPOINT and LRS_AUTH are server-only environment variables for an approved LRS. Never include them in the public directory or committed files. Without them, statements remain pending and the UI says so.
SCORM packages require a real LMS interoperability test. SCORM 2004 is unsupported.
Public deployment, authenticated LMS roles/enrollment, xAPI conformance, screen-reader testing and persistent backend hosting remain release blockers.
No production media has been generated. Optional lesson.media fields: videoUrl, captionsUrl, transcript, chapters. Watch is not considered delivered until equivalent captioned media is supplied and tested.

