import{readFile,writeFile}from'node:fs/promises';
let a=await readFile('public/app.js','utf8');a="import{performancePractice}from'./performance.js';\n"+a;
const start=a.indexOf('if(c.designNotes?.performanceTask){const task='),end=a.indexOf('main.append(task)}};',start);if(start<0||end<0)throw Error('Expected practice block absent');a=a.slice(0,start)+'};'+a.slice(end+'main.append(task)}};'.length);
a=a.replace(" const actions=el('div',undefined,'actions');actions.append(button('Previous lesson'"," const writing=performancePractice({document,course:c,lesson:l,key,storage:localStorage});if(writing)main.append(writing);\n const actions=el('div',undefined,'actions');actions.append(button('Previous lesson'");
await writeFile('public/app.js',a);
let b=await readFile('scripts/build.mjs','utf8');b=b.replace("'core.js','scorm.js'","'core.js','scorm.js','performance.js'");await writeFile('scripts/build.mjs',b);
