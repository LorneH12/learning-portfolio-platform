import{readdir,readFile,mkdir,copyFile,writeFile,cp}from'node:fs/promises';
import path from'node:path';import JSZip from'jszip';import{validateCourse}from'../public/core.js';import{createHash}from'node:crypto';
for(const d of['public/courses','public/vendor','public/licenses','releases','evidence'])await mkdir(d,{recursive:true});
for(const[src,dst]of[['node_modules/marked/lib/marked.esm.js','marked.esm.js'],['node_modules/dompurify/dist/purify.es.mjs','purify.es.mjs']])await copyFile(src,'public/vendor/'+dst);
for(const pkg of['marked','dompurify','jszip']){const dir='node_modules/'+pkg;for(const f of await readdir(dir))if(/^licen[cs]e/i.test(f))await copyFile(dir+'/'+f,'public/licenses/'+pkg+'-'+f)}
await mkdir('content',{recursive:true});const courses=[];
for(const name of await readdir('content')){if(!name.endsWith('.json'))continue;const c=JSON.parse(await readFile('content/'+name,'utf8'));const es=validateCourse(c);if(es.length)throw Error(name+': '+es.join('; '));courses.push(c);await writeFile('public/courses/'+c.id+'.json',JSON.stringify(c,null,2))}
const catalog=cs=>JSON.stringify(cs.map(({id,title,summary,durationMinutes})=>({id,title,summary,durationMinutes})),null,2);
await writeFile('public/courses/index.json',catalog(courses));
const xml=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');
async function tree(dir){const result=[];try{for(const e of await readdir('public/'+dir,{withFileTypes:true})){const p=dir+'/'+e.name;if(e.isDirectory())result.push(...await tree(p));else result.push(p)}}catch(e){if(e.code!=='ENOENT')throw e}return result}
const common=['index.html','styles.css','panels.css','app.js','core.js','scorm.js','performance.js',...await tree('vendor'),...await tree('licenses')];
const hashes=[];
for(const c of courses){const z=new JSZip();const files=[...common,...await tree('media/'+c.id)];try{await readFile('public/storyboards/'+c.id+'.json');files.push('storyboards/'+c.id+'.json')}catch(e){if(e.code!=='ENOENT')throw e}
for(const f of files)z.file(f,await readFile('public/'+f),{date:new Date('2026-01-01T00:00:00Z')});
z.file('courses/'+c.id+'.json',JSON.stringify(c),{date:new Date('2026-01-01T00:00:00Z')});z.file('courses/index.json',catalog([c]),{date:new Date('2026-01-01T00:00:00Z')});
const manifest='<?xml version="1.0" encoding="UTF-8"?>\n<manifest identifier="'+xml(c.id)+'" version="1.0" xmlns="http://www.imsproject.org/xsd/imscp_rootv1p1p2" xmlns:adlcp="http://www.adlnet.org/xsd/adlcp_rootv1p2"><metadata><schema>ADL SCORM</schema><schemaversion>1.2</schemaversion></metadata><organizations default="ORG"><organization identifier="ORG"><title>'+xml(c.title)+'</title><item identifier="ITEM" identifierref="SCO"><title>'+xml(c.title)+'</title></item></organization></organizations><resources><resource identifier="SCO" type="webcontent" adlcp:scormtype="sco" href="index.html?course='+xml(c.id)+'">'+[...files,'courses/'+c.id+'.json','courses/index.json'].map(f=>'<file href="'+xml(f)+'"/>').join('')+'</resource></resources></manifest>';
z.file('imsmanifest.xml',manifest,{date:new Date('2026-01-01T00:00:00Z')});z.file('README.txt','Independent portfolio sample. SCORM 1.2 package candidate: actual LMS import, launch, resume and completion verification still required. SCORM 2004 unsupported.\n'+c.disclaimer,{date:new Date('2026-01-01T00:00:00Z')});
const bytes=await z.generateAsync({type:'nodebuffer',compression:'DEFLATE'});await writeFile('releases/'+c.id+'-scorm12.zip',bytes);hashes.push({id:c.id,sha256:createHash('sha256').update(bytes).digest('hex'),bytes:bytes.length,files:Object.keys(z.files).filter(f=>!z.files[f].dir)})}
await cp('public','dist',{recursive:true});await writeFile('evidence/packages.json',JSON.stringify(hashes,null,2));console.log(JSON.stringify({courses:courses.length,packages:hashes},null,2));
