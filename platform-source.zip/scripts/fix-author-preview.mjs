import fs from 'node:fs';
const path='public/app.js';let s=fs.readFileSync(path,'utf8');
s=s.replace("try{const r=await fetch('storyboards/'","if(!preview){try{const r=await fetch('storyboards/'").replace("catch{}if(c.brand?.theme", "catch{}}if(c.brand?.theme");
s=s.replace("state=scorm.init();", "state=preview?freshState():scorm.init();");
fs.writeFileSync(path,s);console.log('Draft preview uses edited source and fresh progress.');
