import{readFile,writeFile,copyFile}from'node:fs/promises';import{createHash}from'node:crypto';import{validateCourse}from'../public/core.js';
const id='adkar-change-foundations',expected=['8d713c5e25d608c1d6d798f135469f97827851f4789e6281852e9399b675cdb0','78eff09329609d85a34a47547e3a23e0b79b2184110d866a177813114d16f403'];
for(const[i,dir]of ['courses','storyboards'].entries()){const p='incoming/'+dir+'/'+id+'.json',b=await readFile(p);if(createHash('sha256').update(b).digest('hex')!==expected[i])throw Error('Hash mismatch '+p);const value=JSON.parse(b);if(dir==='courses'){const e=validateCourse(value);if(e.length)throw Error(e.join('; '))}await copyFile(p,(dir==='courses'?'content':'public/storyboards')+'/'+id+'.json')}
let app=await readFile('public/app.js','utf8');
app=app.replace("if(r.ok)c.presentation=await r.json()","if(r.ok){const raw=await r.json();c.presentation=raw.courses?.find(x=>x.courseId===c.id)||raw;for(const l of c.presentation.lessons||[])for(const p of l.panels||[])p.paragraphs??=p.sourceContentMapping?.paragraphNumbersOneBased||[]}");
await writeFile('public/app.js',app);
await writeFile('evidence/adkar-import.json',JSON.stringify({id,verifiedSHA256:expected,lessons:5,panels:20,sourcePreserved:true,normalization:'Runtime selects matching course and maps paragraph references; original storyboard file retained'},null,2));
console.log('ADKAR course and storyboard hashes verified, source copied; runtime supports original storyboard wrapper.');
