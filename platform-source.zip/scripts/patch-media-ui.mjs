import{readFile,writeFile}from'node:fs/promises';
let s=await readFile('public/app.js','utf8');
s=s.replace("main.append(v,err);if(l.media.transcript)","const captions=button('Show optional captions',()=>{const show=tr.track.mode!=='showing';tr.track.mode=show?'showing':'disabled';captions.textContent=show?'Hide optional captions':'Show optional captions';captions.setAttribute('aria-pressed',String(show))},'secondary');captions.setAttribute('aria-pressed',String(tr.default));main.append(v,captions,err);if(l.media.burnedCaptions)main.append(el('p','This video includes visible captions. Optional captions can be enabled with the button above.','muted'));if(l.media.transcript)");
await writeFile('public/app.js',s);
