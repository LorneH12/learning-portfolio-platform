import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {randomUUID} from 'node:crypto';
import {mkdir} from 'node:fs/promises';
import path from 'node:path';
const base='http://127.0.0.1:4175';
await mkdir('.private/test-data',{recursive:true});
const db=path.resolve('.private/test-data/'+randomUUID()+'.sqlite');
async function start(){const p=spawn(process.execPath,['server.mjs'],{env:{...process.env,PORT:'4175',DB_FILE:db},stdio:['ignore','pipe','pipe']});await new Promise((resolve,reject)=>{p.stdout.once('data',resolve);p.once('error',reject);p.once('exit',code=>reject(Error('Server exited '+code)))});return p}
async function stop(p){p.kill();await new Promise(r=>p.once('exit',r))}
const payload={id:randomUUID(),verb:'initialized',courseId:'ebitda-foundations',timestamp:new Date().toISOString()};
const send=(body,origin=base)=>fetch(base+'/api/events',{method:'POST',headers:{'Content-Type':'application/json','Origin':origin},body:JSON.stringify(body)});
test('local queue stores, deduplicates, persists and rejects invalid requests (not LRS conformance)',async()=>{
 let p=await start();try{
 assert.equal((await send([payload])).status,200);
 assert.equal((await send([payload])).status,200);
 let r=await(await fetch(base+'/api/records')).json();assert.equal(r.records.length,1);assert.equal(r.records[0].lrsDelivered,false);
 assert.equal((await send([{...payload,id:'invalid'}])).status,400);
 assert.equal((await send([payload],'https://untrusted.example')).status,403);
 assert.equal((await fetch(base+'/.private/library/transfer.json')).status,404);
 await stop(p);p=await start();r=await(await fetch(base+'/api/records')).json();assert.equal(r.records.length,1);assert.equal(r.records[0].statement.id,payload.id);
 }finally{await stop(p)}
});
